package com.fqz.bluetoothterminal.bluetooth

object BtActions {
    const val ACTION_STATE = "com.fqz.bluetoothterminal.ACTION_BT_STATE"
    const val ACTION_RX = "com.fqz.bluetoothterminal.ACTION_BT_RX"
    const val ACTION_LOG = "com.fqz.bluetoothterminal.ACTION_BT_LOG"
    const val ACTION_AI = "com.fqz.bluetoothterminal.ACTION_AI"

    const val EXTRA_STATE = "state"
    const val EXTRA_DEVICE_NAME = "device_name"
    const val EXTRA_DEVICE_ADDRESS = "device_address"
    const val EXTRA_TEXT = "text"
    const val EXTRA_TYPE = "type"
}

