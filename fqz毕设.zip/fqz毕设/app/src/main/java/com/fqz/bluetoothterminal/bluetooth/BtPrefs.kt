package com.fqz.bluetoothterminal.bluetooth

import android.content.Context

object BtPrefs {
    private const val PREFS_NAME = "bt_prefs"
    private const val KEY_LAST_DEVICE_NAME = "last_device_name"
    private const val KEY_LAST_DEVICE_ADDRESS = "last_device_address"

    fun setLastDevice(context: Context, name: String?, address: String?) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LAST_DEVICE_NAME, name)
            .putString(KEY_LAST_DEVICE_ADDRESS, address)
            .apply()
    }

    fun getLastDeviceName(context: Context): String? {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_LAST_DEVICE_NAME, null)
    }

    fun getLastDeviceAddress(context: Context): String? {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_LAST_DEVICE_ADDRESS, null)
    }
}

