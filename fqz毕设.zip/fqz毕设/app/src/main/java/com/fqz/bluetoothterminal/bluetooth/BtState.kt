package com.fqz.bluetoothterminal.bluetooth

object BtState {
    const val DISCONNECTED = 0
    const val CONNECTING = 1
    const val CONNECTED = 2
}

