package com.fqz.bluetoothterminal.ui.ai

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import android.view.LayoutInflater
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.widget.TextView
import com.fqz.bluetoothterminal.R
import com.fqz.bluetoothterminal.bluetooth.BtActions
import com.fqz.bluetoothterminal.bluetooth.BtPrefs
import com.fqz.bluetoothterminal.bluetooth.BtState
import com.fqz.bluetoothterminal.bluetooth.BluetoothSerialService
import com.fqz.bluetoothterminal.databinding.ActivityAiBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.widget.Toast
import org.json.JSONObject

class AiActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAiBinding
    private val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private var service: BluetoothSerialService? = null
    private var serviceBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val b = binder as? BluetoothSerialService.LocalBinder ?: return
            service = b.getService()
            serviceBound = true
            val svc = service ?: return
            val s = svc.getState()
            val devName = svc.getConnectedDeviceName() ?: BtPrefs.getLastDeviceName(this@AiActivity)
            val devAddr = svc.getConnectedDeviceAddress() ?: BtPrefs.getLastDeviceAddress(this@AiActivity)
            updateStateUi(s, devName, devAddr)
            if (s != BtState.CONNECTED) {
                Toast.makeText(this@AiActivity, "未连接蓝牙设备，无法开始AI分析。请先在“通信”页连接并接收数据。", Toast.LENGTH_SHORT).show()
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
            service = null
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BtActions.ACTION_STATE -> {
                    val s = intent.getIntExtra(BtActions.EXTRA_STATE, BtState.DISCONNECTED)
                    val name = intent.getStringExtra(BtActions.EXTRA_DEVICE_NAME)
                    val addr = intent.getStringExtra(BtActions.EXTRA_DEVICE_ADDRESS)
                    updateStateUi(s, name, addr)
                }
                BtActions.ACTION_AI -> {
                    val type = intent.getStringExtra(BtActions.EXTRA_TYPE).orEmpty()
                    val text = intent.getStringExtra(BtActions.EXTRA_TEXT).orEmpty()
                    if (text.isNotBlank()) handleAi(type, text)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.btnAnalyze.setOnClickListener {
            val svc = service
            if (svc != null && svc.getState() == BtState.CONNECTED) {
                svc.requestAiSummaryNow()
                Toast.makeText(this, "正在请求AI进行实时分析...", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "错误：蓝牙未连接，无法分析。", Toast.LENGTH_SHORT).show()
            }
        }
        binding.btnClear.setOnClickListener {
            binding.aiCardsContainer.removeAllViews()
            binding.tvRisk.text = "RISK: —"
        }

        registerReceivers()
        bindService(Intent(this, BluetoothSerialService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)

        val lastName = BtPrefs.getLastDeviceName(this)
        val lastAddr = BtPrefs.getLastDeviceAddress(this)
        binding.tvDevice.text = formatDevice(lastName, lastAddr)
        updateStateUi(BtState.DISCONNECTED, lastName, lastAddr)
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { unregisterReceiver(receiver) }
        if (serviceBound) {
            runCatching { unbindService(serviceConnection) }
            serviceBound = false
            service = null
        }
    }

    private fun registerReceivers() {
        val filter = IntentFilter().apply {
            addAction(BtActions.ACTION_STATE)
            addAction(BtActions.ACTION_AI)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    private fun updateStateUi(state: Int, name: String?, address: String?) {
        binding.tvDevice.text = formatDevice(name, address)
        binding.tvState.text = when (state) {
            BtState.CONNECTING -> getString(R.string.label_connecting)
            BtState.CONNECTED -> getString(R.string.label_connected)
            else -> getString(R.string.label_not_connected)
        }
    }

    private fun handleAi(type: String, text: String) {
        val now = sdf.format(Date())

        when (type) {
            "summary" -> {
                runCatching {
                    val json = JSONObject(text)
                    createSummaryCard(json, now)
                }.onFailure {
                    // 如果解析失败，显示Toast
                    Toast.makeText(this, "AI分析数据解析失败", Toast.LENGTH_SHORT).show()
                }
                binding.aiScroll.post { binding.aiScroll.fullScroll(android.view.View.FOCUS_DOWN) }
            }
            "rule" -> {
                val risk = runCatching { JSONObject(text).optString("risk", "") }.getOrDefault("")
                if (risk.isNotBlank()) {
                    binding.tvRisk.text = "RISK: $risk"
                }
                // 规则数据也可以创建卡片，但暂时只更新风险标签
            }
            else -> {
                // info 或其他类型，显示Toast
                Toast.makeText(this, "AI分析: $type", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun createSummaryCard(json: JSONObject, time: String) {
        val inflater = LayoutInflater.from(this)
        val cardView = inflater.inflate(R.layout.item_ai_card, binding.aiCardsContainer, false)

        // 风险等级
        val risk = json.optString("risk", "NORMAL").uppercase()
        val riskView = cardView.findViewById<TextView>(R.id.tvRisk)
        riskView.text = risk

        // 设置风险标签颜色和圆角背景
        val riskColorRes = when (risk) {
            "ALERT" -> R.color.risk_alert
            "WARN" -> R.color.risk_warn
            else -> R.color.risk_normal
        }
        val riskColor = ContextCompat.getColor(this, riskColorRes)
        val drawable = GradientDrawable()
        val radius = 20f * resources.displayMetrics.density
        drawable.cornerRadius = radius
        drawable.setColor(riskColor)
        riskView.background = drawable

        // 标题和时间
        cardView.findViewById<TextView>(R.id.tvTime).text = time

        // 心率数据
        val hrAvg = json.optDouble("hr_avg", 0.0)
        val hrMin = json.optInt("hr_min", 0)
        val hrMax = json.optInt("hr_max", 0)
        val heartText = if (hrAvg > 0) {
            String.format(Locale.getDefault(), "%.0f bpm (%.0f-%.0f)", hrAvg, hrMin.toDouble(), hrMax.toDouble())
        } else {
            "—"
        }
        cardView.findViewById<TextView>(R.id.tvHeartValue).text = heartText

        // 血氧数据
        val spo2Min = json.optInt("spo2_min", 0)
        val spo2Max = json.optInt("spo2_max", 0)
        val oxygenText = if (spo2Min > 0 && spo2Max > 0) {
            String.format(Locale.getDefault(), "%d-%d%%", spo2Min, spo2Max)
        } else {
            "—"
        }
        cardView.findViewById<TextView>(R.id.tvOxygenValue).text = oxygenText

        // 体温数据
        val tempMin = json.optDouble("temp_min", 0.0)
        val tempMax = json.optDouble("temp_max", 0.0)
        val tempText = if (tempMin > 0 && tempMax > 0) {
            String.format(Locale.getDefault(), "%.1f-%.1f℃", tempMin, tempMax)
        } else {
            "—"
        }
        cardView.findViewById<TextView>(R.id.tvTempValue).text = tempText

        // 数据统计
        val count = json.optInt("count", 0)
        val windowMs = json.optLong("to_ts_ms", 0) - json.optLong("from_ts_ms", 0)
        val minutes = (windowMs / 60000L).coerceAtLeast(1)
        val statsText = "基于最近${minutes}分钟的${count}条数据"
        cardView.findViewById<TextView>(R.id.tvStats).text = statsText

        // 健康建议
        val suggestion = json.optString("suggestion", "暂无建议")
        cardView.findViewById<TextView>(R.id.tvSuggestion).text = suggestion

        // 主要发现
        val reasonsArray = json.optJSONArray("top_reasons")
        val reasonsText = if (reasonsArray != null && reasonsArray.length() > 0) {
            val reasons = mutableListOf<String>()
            for (i in 0 until reasonsArray.length()) {
                reasons.add("• ${reasonsArray.getString(i)}")
            }
            reasons.joinToString("\n")
        } else {
            "• 数据正常范围内"
        }
        cardView.findViewById<TextView>(R.id.tvReasons).text = reasonsText

        // 添加到容器
        binding.aiCardsContainer.addView(cardView, 0) // 添加到顶部，最新分析在最上面
    }

    private fun formatDevice(name: String?, address: String?): String {
        val n = name?.takeIf { it.isNotBlank() } ?: "Unknown"
        val a = address?.takeIf { it.isNotBlank() } ?: "—"
        return "$n ($a)"
    }
}
