@echo off
setlocal

set DIRNAME=%~dp0
if "%DIRNAME%" == "" set DIRNAME=.
set APP_HOME=%DIRNAME%

if defined LOCALAPPDATA (
  set "CACHE_HOME=%LOCALAPPDATA%\fqz-bluetoothterminal-cache"
) else (
  set "CACHE_HOME=%USERPROFILE%\AppData\Local\fqz-bluetoothterminal-cache"
)

set JDK_MAJOR=17
set JDK_URL=https://aka.ms/download-jdk/microsoft-jdk-17.0.10-windows-x64.zip
set "JDK_DIR=%CACHE_HOME%\jdk-dist"
set JDK_ZIP=%JDK_DIR%\jdk-%JDK_MAJOR%-windows-x64.zip

if defined JAVA_HOME (
  if not exist "%JAVA_HOME%\bin\java.exe" set JAVA_HOME=
  if not exist "%JAVA_HOME%\bin\jlink.exe" set JAVA_HOME=
)
if not defined JAVA_HOME (
  if exist "C:\Program Files\Android\Android Studio\jbr\bin\jlink.exe" set "JAVA_HOME=C:\Program Files\Android\Android Studio\jbr"
)
if not defined JAVA_HOME (
  if exist "C:\Program Files\JetBrains\PyCharm 2024.1.4\jbr\bin\jlink.exe" set "JAVA_HOME=C:\Program Files\JetBrains\PyCharm 2024.1.4\jbr"
)
if not defined JAVA_HOME (
  for /d %%D in ("%JDK_DIR%\jdk-%JDK_MAJOR%*") do (
    if exist "%%D\bin\jlink.exe" set "JAVA_HOME=%%D"
  )
)
if not defined JAVA_HOME (
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference='Stop';" ^
    "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;" ^
    "$dir='%JDK_DIR%'; $zip='%JDK_ZIP%'; $tmp=($zip + '.download'); $url='%JDK_URL%';" ^
    "New-Item -ItemType Directory -Force -Path $dir | Out-Null;" ^
    "if (Test-Path -LiteralPath $zip) { $len = (Get-Item -LiteralPath $zip).Length } else { $len = 0 }" ^
    "if ($len -lt 120000000) { if (Get-Command curl.exe -ErrorAction SilentlyContinue) { & curl.exe -L --fail --retry 5 --retry-delay 2 -C - -o $tmp $url; if ($LASTEXITCODE -ne 0) { throw ('curl failed: ' + $LASTEXITCODE) } } else { Invoke-WebRequest -Uri $url -OutFile $tmp }; if (!(Test-Path -LiteralPath $tmp)) { throw 'JDK download failed.' }; Remove-Item -Force -ErrorAction SilentlyContinue -LiteralPath $zip; Move-Item -Force -LiteralPath $tmp -Destination $zip }" ^
    "Get-ChildItem -LiteralPath $dir -Directory -Filter ('jdk-%JDK_MAJOR%*') -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue;" ^
    "Expand-Archive -LiteralPath $zip -DestinationPath $dir -Force;"
  if errorlevel 1 exit /b 1
  for /d %%D in ("%JDK_DIR%\jdk-%JDK_MAJOR%*") do (
    if exist "%%D\bin\jlink.exe" set "JAVA_HOME=%%D"
  )
)

set GRADLE_VERSION=8.7
set DIST_URL=https://downloads.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip
set "DIST_DIR=%CACHE_HOME%\gradle-dist"
set ZIP_FILE=%DIST_DIR%\gradle-%GRADLE_VERSION%-bin.zip
set GRADLE_HOME=%DIST_DIR%\gradle-%GRADLE_VERSION%
set GRADLE_CMD=%GRADLE_HOME%\bin\gradle.bat

if not exist "%GRADLE_CMD%" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference='Stop';" ^
    "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;" ^
    "$distDir = '%DIST_DIR%';" ^
    "$zipFile = '%ZIP_FILE%';" ^
    "$zipTmp = $zipFile + '.download';" ^
    "$url = '%DIST_URL%';" ^
    "$gradleCmd = '%GRADLE_CMD%';" ^
    "New-Item -ItemType Directory -Force -Path $distDir | Out-Null;" ^
    "if (Test-Path -LiteralPath $zipFile) { $len = (Get-Item -LiteralPath $zipFile).Length } else { $len = 0 }" ^
    "if ($len -lt 100000000) { for ($i=0; $i -lt 5; $i++) { try { if (Get-Command curl.exe -ErrorAction SilentlyContinue) { & curl.exe -L --fail --retry 5 --retry-delay 2 -C - -o $zipTmp $url; if ($LASTEXITCODE -ne 0) { throw ('curl failed: ' + $LASTEXITCODE) } } else { Invoke-WebRequest -Uri $url -OutFile $zipTmp } ; if (!(Test-Path -LiteralPath $zipTmp)) { throw 'Gradle download failed.' }; break } catch { if ($i -eq 4) { throw }; Start-Sleep -Seconds (2 + $i) } }; Remove-Item -Force -ErrorAction SilentlyContinue -LiteralPath $zipFile; Move-Item -Force -LiteralPath $zipTmp -Destination $zipFile }" ^
    "if (Test-Path -LiteralPath '%GRADLE_HOME%') { Remove-Item -Recurse -Force -LiteralPath '%GRADLE_HOME%' }" ^
    "for ($i=0; $i -lt 5; $i++) { try { Expand-Archive -LiteralPath $zipFile -DestinationPath $distDir -Force; break } catch { if ($i -eq 4) { throw }; Start-Sleep -Milliseconds 600 } }" ^
    "if (!(Test-Path -LiteralPath $gradleCmd)) { throw ('Gradle extract failed: ' + $gradleCmd) }"
  if errorlevel 1 exit /b 1
)

"%GRADLE_CMD%" %*
set EXIT_CODE=%ERRORLEVEL%
endlocal & exit /b %EXIT_CODE%
